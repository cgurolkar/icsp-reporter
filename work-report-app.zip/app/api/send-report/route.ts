import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.json()

    // Get email settings from storage
    const settings = await getEmailSettings()

    // Generate PDF-ready content for both pages
    const mainReportContent = generatePDFMainReport(formData)
    const expensesPageContent = generatePDFExpensesPage(formData)

    // For MVP: Log email content to console instead of sending
    console.log("=== PDF REPORT GENERATED ===")
    console.log(`Recipients: ${settings.emails.join(", ")}`)
    console.log(`Subject: Günlük Çalışma Raporu - ${formData.basicInfo.date}`)
    console.log("Main Report Content:")
    console.log(mainReportContent)
    console.log("=== EXPENSES PAGE ===")
    console.log(expensesPageContent)
    console.log("=== END PDF REPORT ===")

    // Simulate email sending delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Return success response with PDF content
    return NextResponse.json({
      success: true,
      message: "Report generated successfully",
      recipients: settings.emails,
      emailContent: mainReportContent + expensesPageContent,
      expensesContent: expensesPageContent,
    })
  } catch (error) {
    console.error("Error generating report:", error)
    return NextResponse.json({ error: "Failed to generate report" }, { status: 500 })
  }
}

async function getEmailSettings() {
  return {
    emails: ["admin@company.com", "manager@company.com"],
    users: ["admin"],
    customFields: [],
  }
}

function generatePDFMainReport(formData: any) {
  return `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="UTF-8">
        <title>Günlük Çalışma Raporu - ${formData.basicInfo.date}</title>
        <style>
          @page {
            size: A4 portrait;
            margin: 15mm;
          }
          
          body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            font-size: 12px;
            line-height: 1.2;
          }
          
          .page {
            width: 100%;
            min-height: 100vh;
            page-break-after: always;
            background: white;
          }
          
          table {
            border-collapse: collapse;
            width: 100%;
            margin: 10px 0;
          }
          
          th, td {
            border: 2px solid #000;
            padding: 6px;
            text-align: left;
            vertical-align: middle;
          }
          
          th {
            background-color: #f0f0f0;
            font-weight: bold;
            text-align: center;
          }
          
          .header {
            background-color: #f0f0f0;
            padding: 15px;
            text-align: center;
            border: 2px solid #000;
            margin-bottom: 15px;
          }
          
          .section-title {
            font-size: 14px;
            font-weight: bold;
            padding: 8px;
            background-color: #f0f0f0;
            border: 1px solid #000;
            margin: 15px 0 5px 0;
          }
          
          .info-box {
            border: 1px solid #000;
            padding: 8px;
            text-align: center;
            min-height: 35px;
            display: flex;
            flex-direction: column;
            justify-content: center;
          }
          
          .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 5px;
            margin-bottom: 15px;
          }
          
          @media print {
            body { -webkit-print-color-adjust: exact; }
            .page { page-break-after: always; }
          }
        </style>
      </head>
      <body>
        <div class="page">
          <div class="header">
            <h1 style="margin: 0; font-size: 18px;">GÜNLÜK ÇALIŞMA RAPORU</h1>
            <div style="display: flex; justify-content: space-between; margin-top: 10px;">
              <span style="font-weight: bold;">TARİH: ${formData.basicInfo.date}</span>
              <span style="font-weight: bold;">${formData.basicInfo.project}</span>
            </div>
          </div>

          <div class="section-title">TEMEL BİLGİLER</div>
          <div class="info-grid">
            <div class="info-box">
              <div style="font-size: 10px; font-weight: bold; margin-bottom: 2px;">MAKİNE SAAT</div>
              <div style="font-size: 14px; font-weight: bold;">${formData.basicInfo.machineHours}</div>
            </div>
            <div class="info-box">
              <div style="font-size: 10px; font-weight: bold; margin-bottom: 2px;">TOPLAM İMALAT (M)</div>
              <div style="font-size: 14px; font-weight: bold;">${formData.basicInfo.totalProduction}</div>
            </div>
            <div class="info-box">
              <div style="font-size: 10px; font-weight: bold; margin-bottom: 2px;">YAPILAN KAZIK ADEDİ</div>
              <div style="font-size: 14px; font-weight: bold;">${formData.basicInfo.pileCount}</div>
            </div>
            <div class="info-box">
              <div style="font-size: 10px; font-weight: bold; margin-bottom: 2px;">KAZIK DELİNEN</div>
              <div style="font-size: 14px; font-weight: bold;">${formData.basicInfo.drilledPile}</div>
            </div>
          </div>

          <div class="section-title">ÜRETİM ÖZETİ</div>
          <table>
            <tbody>
              <tr><td style="font-weight: bold; background-color: #f0f0f0;">TOPLAM İMALAT (M)</td><td style="text-align: center; font-weight: bold;">${formData.productionSummary.totalProduction}</td></tr>
              <tr><td style="font-weight: bold; background-color: #f0f0f0;">TOPLAM KAZIK SAYISI</td><td style="text-align: center; font-weight: bold;">${formData.productionSummary.totalPileCount}</td></tr>
              <tr><td style="font-weight: bold; background-color: #f0f0f0;">GÜNLÜK YAPILAN KAZIK</td><td style="text-align: center; font-weight: bold;">${formData.productionSummary.dailyPileCount}</td></tr>
              <tr><td style="font-weight: bold; background-color: #f0f0f0;">TOPLAM YAPILAN KAZIK SAYISI</td><td style="text-align: center; font-weight: bold;">${formData.productionSummary.totalCompletedPiles}</td></tr>
              <tr><td style="font-weight: bold; background-color: #f0f0f0;">KALAN KAZIK SAYISI</td><td style="text-align: center; font-weight: bold;">${formData.productionSummary.remainingPiles}</td></tr>
              <tr><td style="font-weight: bold; background-color: #f0f0f0;">DEMİR İNDİRİLEN KAZIK</td><td style="text-align: center; font-weight: bold;">${formData.productionSummary.steelLoweredPiles}</td></tr>
              <tr><td style="font-weight: bold; background-color: #f0f0f0;">BETON DÖKÜLEN KAZIK</td><td style="text-align: center; font-weight: bold;">${formData.productionSummary.concretePoured}</td></tr>
            </tbody>
          </table>

          <div class="section-title">PERSONEL</div>
          <table>
            <thead>
              <tr><th>MÜH</th><th>FORMEN</th><th>OPERATOR</th><th>YAĞCI</th><th>KAYNAKÇI</th><th>DİĞER</th><th>TOPLAM</th></tr>
            </thead>
            <tbody>
              <tr>
                <td style="text-align: center; font-weight: bold;">${formData.personnel.engineer}</td>
                <td style="text-align: center; font-weight: bold;">${formData.personnel.foreman}</td>
                <td style="text-align: center; font-weight: bold;">${formData.personnel.operator}</td>
                <td style="text-align: center; font-weight: bold;">${formData.personnel.oiler}</td>
                <td style="text-align: center; font-weight: bold;">${formData.personnel.welder}</td>
                <td style="text-align: center; font-weight: bold;">${formData.personnel.other}</td>
                <td style="text-align: center; font-weight: bold; background-color: #f0f0f0;">${formData.personnel.total}</td>
              </tr>
            </tbody>
          </table>

          <div class="section-title">ARAÇ - GEREÇ</div>
          <table>
            <thead>
              <tr><th>VİNÇ</th><th>LOADER</th><th>KAMYON</th><th>PICK UP</th><th>BİNEK</th><th>SERVİS</th><th>TOPLAM</th></tr>
            </thead>
            <tbody>
              <tr>
                <td style="text-align: center; font-weight: bold;">${formData.vehicles.crane}</td>
                <td style="text-align: center; font-weight: bold;">${formData.vehicles.loader}</td>
                <td style="text-align: center; font-weight: bold;">${formData.vehicles.truck}</td>
                <td style="text-align: center; font-weight: bold;">${formData.vehicles.pickup}</td>
                <td style="text-align: center; font-weight: bold;">${formData.vehicles.car}</td>
                <td style="text-align: center; font-weight: bold;">${formData.vehicles.service}</td>
                <td style="text-align: center; font-weight: bold; background-color: #f0f0f0;">${formData.vehicles.total}</td>
              </tr>
            </tbody>
          </table>

          <div class="section-title">MAKİNE VE ARAÇLAR İÇİN KULLANILAN MAZOT</div>
          <table>
            <thead>
              <tr><th>MAKİNE</th><th>DEVİR</th><th>GELEN</th><th>KALAN</th><th>KULLANILAN</th></tr>
            </thead>
            <tbody>
              ${formData.fuel.machines
                .map(
                  (machine: any) => `
                <tr>
                  <td style="text-align: center; font-weight: bold;">${machine.name}</td>
                  <td style="text-align: center; font-weight: bold;">${machine.shift}</td>
                  <td style="text-align: center; font-weight: bold;">${machine.incoming}</td>
                  <td style="text-align: center; font-weight: bold;">${machine.remaining}</td>
                  <td style="text-align: center; font-weight: bold;">${machine.used}</td>
                </tr>
              `,
                )
                .join("")}
            </tbody>
          </table>

          <div class="section-title">KAZIK DETAYLARI</div>
          <table>
            <thead>
              <tr><th>KAZIK</th><th>DELİNEN</th><th>NOTLAR</th></tr>
            </thead>
            <tbody>
              ${formData.pileDetails
                .filter((pile: any) => pile.drilled || pile.notes)
                .map(
                  (pile: any) => `
                <tr>
                  <td style="text-align: center; font-weight: bold;">${pile.pileNumber}</td>
                  <td style="text-align: center;">${pile.drilled}</td>
                  <td>${pile.notes}</td>
                </tr>
              `,
                )
                .join("")}
            </tbody>
          </table>

          ${
            formData.notes
              ? `
            <div class="section-title">BAKIM / MALZEME / NOTLAR</div>
            <div style="border: 1px solid #000; min-height: 60px; padding: 8px; background: white; white-space: pre-wrap;">${formData.notes}</div>
          `
              : ""
          }
        </div>
      </body>
    </html>
  `
}

function generatePDFExpensesPage(formData: any) {
  return `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="UTF-8">
        <title>Harcamalar - ${formData.basicInfo.date}</title>
        <style>
          @page {
            size: A4 portrait;
            margin: 15mm;
          }
          
          body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            font-size: 12px;
            line-height: 1.2;
          }
          
          table {
            border-collapse: collapse;
            width: 100%;
            margin: 10px 0;
          }
          
          th, td {
            border: 2px solid #000;
            padding: 6px;
            text-align: left;
            vertical-align: middle;
          }
          
          th {
            background-color: #f0f0f0;
            font-weight: bold;
            text-align: center;
          }
          
          .header {
            background-color: #f0f0f0;
            padding: 15px;
            text-align: center;
            border: 2px solid #000;
            margin-bottom: 15px;
          }
          
          @media print {
            body { -webkit-print-color-adjust: exact; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <h1 style="margin: 0; font-size: 18px;">HARCAMALAR</h1>
          <div style="display: flex; justify-content: space-between; margin-top: 10px;">
            <span style="font-weight: bold;">TARİH: ${formData.basicInfo.date}</span>
            <span style="font-weight: bold;">${formData.basicInfo.project}</span>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th style="width: 10%;">#</th>
              <th style="width: 60%;">AÇIKLAMA</th>
              <th style="width: 30%;">TUTAR (IQD)</th>
            </tr>
          </thead>
          <tbody>
            ${Array.from({ length: Math.max(15, formData.expenses.length) }, (_, index) => {
              const expense = formData.expenses[index]
              return `
                <tr>
                  <td style="text-align: center; font-weight: bold;">${index + 1}.</td>
                  <td>${expense?.description || ""}</td>
                  <td style="text-align: right; font-weight: bold;">${expense?.amount ? expense.amount.toLocaleString() : ""}</td>
                </tr>
              `
            }).join("")}
            <tr style="background-color: #f0f0f0;">
              <td colspan="2" style="text-align: center; font-weight: bold;">TOPLAM:</td>
              <td style="text-align: right; font-weight: bold;">${formData.expenses.reduce((sum: number, exp: any) => sum + exp.amount, 0).toLocaleString()} IQD</td>
            </tr>
          </tbody>
        </table>
      </body>
    </html>
  `
}
