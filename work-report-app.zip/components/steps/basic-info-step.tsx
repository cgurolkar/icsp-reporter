"use client"

import type React from "react"

import { Grid, TextField, Typography, Box, Paper } from "@mui/material"
import { useLanguage } from "@/contexts/language-context"
import type { BasicInfo } from "@/types/form-data"

interface BasicInfoStepProps {
  data: BasicInfo
  onChange: (data: BasicInfo) => void
}

export default function BasicInfoStep({ data, onChange }: BasicInfoStepProps) {
  const { t } = useLanguage()

  const handleChange = (field: keyof BasicInfo) => (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange({
      ...data,
      [field]: event.target.value,
    })
  }

  return (
    <Box>
      <Typography variant="h6" gutterBottom sx={{ color: "primary.main", fontWeight: 600, mb: 3 }}>
        {t("basic_info")}
      </Typography>
      <Paper
        sx={{ p: 3, background: "linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%)", border: "1px solid #2196f3" }}
      >
        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label={t("date")}
              type="date"
              value={data.date}
              onChange={handleChange("date")}
              InputLabelProps={{ shrink: true }}
              sx={{
                "& .MuiOutlinedInput-root": {
                  backgroundColor: "white",
                  "&:hover fieldset": { borderColor: "primary.main" },
                },
              }}
            />
          </Grid>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label={t("project")}
              value={data.project}
              onChange={handleChange("project")}
              placeholder="SHAQLAWA / PROJECT"
              sx={{
                "& .MuiOutlinedInput-root": {
                  backgroundColor: "white",
                  "&:hover fieldset": { borderColor: "primary.main" },
                },
              }}
            />
          </Grid>
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              label={t("machine_hours")}
              type="number"
              value={data.machineHours}
              onChange={handleChange("machineHours")}
              sx={{
                "& .MuiOutlinedInput-root": {
                  backgroundColor: "white",
                  "&:hover fieldset": { borderColor: "primary.main" },
                },
              }}
            />
          </Grid>
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              label={t("total_production")}
              type="number"
              value={data.totalProduction}
              onChange={handleChange("totalProduction")}
              sx={{
                "& .MuiOutlinedInput-root": {
                  backgroundColor: "white",
                  "&:hover fieldset": { borderColor: "primary.main" },
                },
              }}
            />
          </Grid>
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              label={t("pile_count")}
              type="number"
              value={data.pileCount}
              onChange={handleChange("pileCount")}
              sx={{
                "& .MuiOutlinedInput-root": {
                  backgroundColor: "white",
                  "&:hover fieldset": { borderColor: "primary.main" },
                },
              }}
            />
          </Grid>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label={t("drilled_pile")}
              type="number"
              value={data.drilledPile}
              onChange={handleChange("drilledPile")}
              sx={{
                "& .MuiOutlinedInput-root": {
                  backgroundColor: "white",
                  "&:hover fieldset": { borderColor: "primary.main" },
                },
              }}
            />
          </Grid>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label={t("concrete_pile")}
              type="number"
              value={data.concretePile}
              onChange={handleChange("concretePile")}
              sx={{
                "& .MuiOutlinedInput-root": {
                  backgroundColor: "white",
                  "&:hover fieldset": { borderColor: "primary.main" },
                },
              }}
            />
          </Grid>
        </Grid>
      </Paper>
    </Box>
  )
}
