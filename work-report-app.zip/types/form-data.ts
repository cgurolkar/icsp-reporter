export interface BasicInfo {
  date: string
  project: string
  machineHours: string
  totalProduction: string
  pileCount: string
  drilledPile: string
  concretePile: string
}

export interface Personnel {
  engineer: number
  foreman: number
  operator: number
  oiler: number
  welder: number
  other: number
  total: number
}

export interface Vehicles {
  crane: number
  loader: number
  truck: number
  pickup: number
  car: number
  service: number
  total: number
}

export interface FuelMachine {
  name: string
  shift: string
  incoming: string
  remaining: string
  used: string
}

export interface Fuel {
  machines: FuelMachine[]
  dailyUsage: string
}

export interface Expense {
  description: string
  amount: number
}

// New interfaces for the missing tables
export interface ProductionSummary {
  totalProduction: string
  totalPileCount: string
  dailyPileCount: string
  totalCompletedPiles: string
  remainingPiles: string
  steelLoweredPiles: string
  concretePoured: string
}

export interface PileDetail {
  pileNumber: number
  drilled: string
  notes: string
}

export interface FormData {
  basicInfo: BasicInfo
  personnel: Personnel
  vehicles: Vehicles
  fuel: Fuel
  expenses: Expense[]
  productionSummary: ProductionSummary
  pileDetails: PileDetail[]
  notes: string
}

export const initialFormData: FormData = {
  basicInfo: {
    date: new Date().toISOString().split("T")[0],
    project: "SHAQLAWA / PROJECT",
    machineHours: "",
    totalProduction: "",
    pileCount: "",
    drilledPile: "",
    concretePile: "",
  },
  personnel: {
    engineer: 0,
    foreman: 0,
    operator: 0,
    oiler: 0,
    welder: 0,
    other: 0,
    total: 0,
  },
  vehicles: {
    crane: 0,
    loader: 0,
    truck: 0,
    pickup: 0,
    car: 0,
    service: 0,
    total: 0,
  },
  fuel: {
    machines: [{ name: "", shift: "", incoming: "", remaining: "", used: "" }],
    dailyUsage: "",
  },
  expenses: [{ description: "", amount: 0 }],
  productionSummary: {
    totalProduction: "",
    totalPileCount: "",
    dailyPileCount: "",
    totalCompletedPiles: "",
    remainingPiles: "",
    steelLoweredPiles: "",
    concretePoured: "",
  },
  pileDetails: Array.from({ length: 10 }, (_, i) => ({
    pileNumber: i + 1,
    drilled: "",
    notes: "",
  })),
  notes: "",
}
