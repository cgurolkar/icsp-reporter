"use client"

import { useState } from "react"
import { Container, Paper, Stepper, Step, StepLabel, Box, Button, Typography, IconButton } from "@mui/material"
import { Settings } from "@mui/icons-material"
import { ThemeProvider } from "@mui/material/styles"
import CssBaseline from "@mui/material/CssBaseline"
import { theme } from "@/lib/theme"
import { LanguageProvider, useLanguage } from "@/contexts/language-context"
import LanguageSelector from "@/components/language-selector"
import BasicInfoStep from "@/components/steps/basic-info-step"
import ProductionSummaryStep from "@/components/steps/production-summary-step"
import PileDetailsStep from "@/components/steps/pile-details-step"
import PersonnelStep from "@/components/steps/personnel-step"
import VehiclesStep from "@/components/steps/vehicles-step"
import FuelStep from "@/components/steps/fuel-step"
import ExpensesStep from "@/components/steps/expenses-step"
import ReviewStep from "@/components/steps/review-step"
import { type FormData, initialFormData } from "@/types/form-data"
import Link from "next/link"

const steps = [
  "basic_info",
  "production_summary",
  "pile_details",
  "personnel",
  "vehicles",
  "fuel",
  "expenses",
  "review",
]

function WorkReportApp() {
  const [activeStep, setActiveStep] = useState(0)
  const [formData, setFormData] = useState<FormData>(initialFormData)
  const { t } = useLanguage()

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1)
  }

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1)
  }

  const handleSubmit = async () => {
    try {
      const response = await fetch("/api/send-report", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        alert(t("report_sent_successfully"))
        setFormData(initialFormData)
        setActiveStep(0)
      } else {
        alert(t("error_sending_report"))
      }
    } catch (error) {
      console.error("Error sending report:", error)
      alert(t("error_sending_report"))
    }
  }

  const updateFormData = (section: keyof FormData, data: any) => {
    setFormData((prev) => ({
      ...prev,
      [section]: data,
    }))
  }

  const renderStepContent = (step: number) => {
    switch (step) {
      case 0:
        return <BasicInfoStep data={formData.basicInfo} onChange={(data) => updateFormData("basicInfo", data)} />
      case 1:
        return (
          <ProductionSummaryStep
            data={formData.productionSummary}
            onChange={(data) => updateFormData("productionSummary", data)}
          />
        )
      case 2:
        return <PileDetailsStep data={formData.pileDetails} onChange={(data) => updateFormData("pileDetails", data)} />
      case 3:
        return <PersonnelStep data={formData.personnel} onChange={(data) => updateFormData("personnel", data)} />
      case 4:
        return <VehiclesStep data={formData.vehicles} onChange={(data) => updateFormData("vehicles", data)} />
      case 5:
        return <FuelStep data={formData.fuel} onChange={(data) => updateFormData("fuel", data)} />
      case 6:
        return <ExpensesStep data={formData.expenses} onChange={(data) => updateFormData("expenses", data)} />
      case 7:
        return <ReviewStep data={formData} onSubmit={handleSubmit} />
      default:
        return null
    }
  }

  return (
    <Container
      maxWidth="lg"
      sx={{ py: 4, minHeight: "100vh", background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)" }}
    >
      <Paper
        elevation={3}
        sx={{ p: 4, borderRadius: 3, background: "rgba(255, 255, 255, 0.95)", backdropFilter: "blur(10px)" }}
      >
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 4 }}>
          <Typography variant="h4" component="h1" gutterBottom sx={{ color: "primary.main", fontWeight: 700 }}>
            {t("daily_work_report")}
          </Typography>
          <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
            <Link href="/admin" passHref>
              <IconButton
                sx={{
                  backgroundColor: "primary.main",
                  color: "white",
                  "&:hover": {
                    backgroundColor: "primary.dark",
                  },
                }}
                title={t("admin_panel")}
              >
                <Settings />
              </IconButton>
            </Link>
            <LanguageSelector />
          </Box>
        </Box>

        <Stepper activeStep={activeStep} sx={{ mb: 4 }} alternativeLabel>
          {steps.map((label, index) => (
            <Step key={label}>
              <StepLabel
                sx={{
                  "& .MuiStepLabel-label": {
                    fontWeight: 500,
                    fontSize: "0.9rem",
                  },
                  "& .MuiStepIcon-root": {
                    fontSize: "1.5rem",
                  },
                }}
              >
                {t(label)}
              </StepLabel>
            </Step>
          ))}
        </Stepper>

        <Box
          sx={{
            minHeight: 400,
            mb: 4,
            p: 3,
            backgroundColor: "background.paper",
            borderRadius: 2,
            border: "1px solid #e0e0e0",
          }}
        >
          {renderStepContent(activeStep)}
        </Box>

        <Box sx={{ display: "flex", justifyContent: "space-between" }}>
          <Button disabled={activeStep === 0} onClick={handleBack} variant="outlined">
            {t("previous")}
          </Button>

          {activeStep < steps.length - 1 ? (
            <Button variant="contained" onClick={handleNext}>
              {t("next")}
            </Button>
          ) : null}
        </Box>
      </Paper>
    </Container>
  )
}

export default function Home() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <LanguageProvider>
        <WorkReportApp />
      </LanguageProvider>
    </ThemeProvider>
  )
}
