"use client"

import type React from "react"

import { Grid, TextField, Typography, Box, Paper, Table, TableBody, TableCell, TableRow } from "@mui/material"
import { useLanguage } from "@/contexts/language-context"
import type { ProductionSummary } from "@/types/form-data"

interface ProductionSummaryStepProps {
  data: ProductionSummary
  onChange: (data: ProductionSummary) => void
}

export default function ProductionSummaryStep({ data, onChange }: ProductionSummaryStepProps) {
  const { t } = useLanguage()

  const handleChange = (field: keyof ProductionSummary) => (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange({
      ...data,
      [field]: event.target.value,
    })
  }

  return (
    <Box>
      <Typography variant="h6" gutterBottom sx={{ color: "info.main", fontWeight: 600, mb: 3 }}>
        {t("production_summary")}
      </Typography>
      <Paper
        sx={{ p: 3, background: "linear-gradient(135deg, #e1f5fe 0%, #b3e5fc 100%)", border: "1px solid #03a9f4" }}
      >
        {/* Form Fields */}
        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label="TOPLAM İMALAT (M)"
              value={data.totalProduction}
              onChange={handleChange("totalProduction")}
              sx={{
                "& .MuiOutlinedInput-root": {
                  backgroundColor: "white",
                  "&:hover fieldset": { borderColor: "info.main" },
                },
              }}
            />
          </Grid>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label="TOPLAM KAZIK SAYISI"
              value={data.totalPileCount}
              onChange={handleChange("totalPileCount")}
              sx={{
                "& .MuiOutlinedInput-root": {
                  backgroundColor: "white",
                  "&:hover fieldset": { borderColor: "info.main" },
                },
              }}
            />
          </Grid>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label="GÜNLÜK YAPILAN KAZIK"
              value={data.dailyPileCount}
              onChange={handleChange("dailyPileCount")}
              sx={{
                "& .MuiOutlinedInput-root": {
                  backgroundColor: "white",
                  "&:hover fieldset": { borderColor: "info.main" },
                },
              }}
            />
          </Grid>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label="TOPLAM YAPILAN KAZIK SAYISI"
              value={data.totalCompletedPiles}
              onChange={handleChange("totalCompletedPiles")}
              sx={{
                "& .MuiOutlinedInput-root": {
                  backgroundColor: "white",
                  "&:hover fieldset": { borderColor: "info.main" },
                },
              }}
            />
          </Grid>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label="KALAN KAZIK SAYISI"
              value={data.remainingPiles}
              onChange={handleChange("remainingPiles")}
              sx={{
                "& .MuiOutlinedInput-root": {
                  backgroundColor: "white",
                  "&:hover fieldset": { borderColor: "info.main" },
                },
              }}
            />
          </Grid>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label="DEMİR İNDİRİLEN KAZIK"
              value={data.steelLoweredPiles}
              onChange={handleChange("steelLoweredPiles")}
              sx={{
                "& .MuiOutlinedInput-root": {
                  backgroundColor: "white",
                  "&:hover fieldset": { borderColor: "info.main" },
                },
              }}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              label="BETON DÖKÜLEN KAZIK"
              value={data.concretePoured}
              onChange={handleChange("concretePoured")}
              sx={{
                "& .MuiOutlinedInput-root": {
                  backgroundColor: "white",
                  "&:hover fieldset": { borderColor: "info.main" },
                },
              }}
            />
          </Grid>
        </Grid>

        {/* Preview Table */}
        <Box sx={{ mt: 4 }}>
          <Typography variant="h6" gutterBottom sx={{ color: "info.main" }}>
            {t("preview")}:
          </Typography>
          <Table size="small" sx={{ border: "2px solid #000", backgroundColor: "white" }}>
            <TableBody>
              <TableRow>
                <TableCell sx={{ border: "1px solid #000", fontWeight: "bold", backgroundColor: "#f0f0f0" }}>
                  TOPLAM İMALAT (M)
                </TableCell>
                <TableCell sx={{ border: "1px solid #000", textAlign: "center", fontWeight: "bold" }}>
                  {data.totalProduction}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell sx={{ border: "1px solid #000", fontWeight: "bold", backgroundColor: "#f0f0f0" }}>
                  TOPLAM KAZIK SAYISI
                </TableCell>
                <TableCell sx={{ border: "1px solid #000", textAlign: "center", fontWeight: "bold" }}>
                  {data.totalPileCount}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell sx={{ border: "1px solid #000", fontWeight: "bold", backgroundColor: "#f0f0f0" }}>
                  GÜNLÜK YAPILAN KAZIK
                </TableCell>
                <TableCell sx={{ border: "1px solid #000", textAlign: "center", fontWeight: "bold" }}>
                  {data.dailyPileCount}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell sx={{ border: "1px solid #000", fontWeight: "bold", backgroundColor: "#f0f0f0" }}>
                  TOPLAM YAPILAN KAZIK SAYISI
                </TableCell>
                <TableCell sx={{ border: "1px solid #000", textAlign: "center", fontWeight: "bold" }}>
                  {data.totalCompletedPiles}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell sx={{ border: "1px solid #000", fontWeight: "bold", backgroundColor: "#f0f0f0" }}>
                  KALAN KAZIK SAYISI
                </TableCell>
                <TableCell sx={{ border: "1px solid #000", textAlign: "center", fontWeight: "bold" }}>
                  {data.remainingPiles}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell sx={{ border: "1px solid #000", fontWeight: "bold", backgroundColor: "#f0f0f0" }}>
                  DEMİR İNDİRİLEN KAZIK
                </TableCell>
                <TableCell sx={{ border: "1px solid #000", textAlign: "center", fontWeight: "bold" }}>
                  {data.steelLoweredPiles}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell sx={{ border: "1px solid #000", fontWeight: "bold", backgroundColor: "#f0f0f0" }}>
                  BETON DÖKÜLEN KAZIK
                </TableCell>
                <TableCell sx={{ border: "1px solid #000", textAlign: "center", fontWeight: "bold" }}>
                  {data.concretePoured}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </Box>
      </Paper>
    </Box>
  )
}
