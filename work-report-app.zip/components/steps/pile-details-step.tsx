"use client"

import type React from "react"

import {
  TextField,
  Typography,
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Button,
  IconButton,
} from "@mui/material"
import { Add, Delete } from "@mui/icons-material"
import { useLanguage } from "@/contexts/language-context"
import type { PileDetail } from "@/types/form-data"

interface PileDetailsStepProps {
  data: PileDetail[]
  onChange: (data: PileDetail[]) => void
}

export default function PileDetailsStep({ data, onChange }: PileDetailsStepProps) {
  const { t } = useLanguage()

  const addPile = () => {
    const newPileNumber = Math.max(...data.map((p) => p.pileNumber), 0) + 1
    onChange([...data, { pileNumber: newPileNumber, drilled: "", notes: "" }])
  }

  const removePile = (index: number) => {
    if (data.length > 1) {
      onChange(data.filter((_, i) => i !== index))
    }
  }

  const updatePile = (index: number, field: keyof PileDetail, value: string | number) => {
    const newData = [...data]
    newData[index] = { ...newData[index], [field]: value }
    onChange(newData)
  }

  const handleKeyPress = (event: React.KeyboardEvent, index: number) => {
    if (event.key === "Enter") {
      event.preventDefault()
      // If this is the last row, add a new one
      if (index === data.length - 1) {
        addPile()
      }
      // Focus on the next row
      setTimeout(() => {
        const nextInput = document.querySelector(`input[data-pile-index="${index + 1}"]`) as HTMLInputElement
        if (nextInput) {
          nextInput.focus()
        }
      }, 100)
    }
  }

  return (
    <Box>
      <Typography variant="h6" gutterBottom sx={{ color: "#795548", fontWeight: 600, mb: 3 }}>
        {t("pile_details")}
      </Typography>
      <Paper
        sx={{ p: 3, background: "linear-gradient(135deg, #efebe9 0%, #d7ccc8 100%)", border: "1px solid #795548" }}
      >
        {/* Form Table */}
        <Table size="small" sx={{ border: "2px solid #000", backgroundColor: "white", mb: 3 }}>
          <TableHead>
            <TableRow sx={{ backgroundColor: "#f0f0f0" }}>
              <TableCell sx={{ border: "1px solid #000", fontWeight: "bold", textAlign: "center", width: "15%" }}>
                KAZIK
              </TableCell>
              <TableCell sx={{ border: "1px solid #000", fontWeight: "bold", textAlign: "center", width: "25%" }}>
                DELİNEN
              </TableCell>
              <TableCell sx={{ border: "1px solid #000", fontWeight: "bold", textAlign: "center", width: "50%" }}>
                NOTLAR
              </TableCell>
              <TableCell sx={{ border: "1px solid #000", fontWeight: "bold", textAlign: "center", width: "10%" }}>
                İŞLEM
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {data.map((pile, index) => (
              <TableRow key={index}>
                <TableCell sx={{ border: "1px solid #000", textAlign: "center", fontWeight: "bold" }}>
                  {pile.pileNumber}
                </TableCell>
                <TableCell sx={{ border: "1px solid #000", p: 0.5 }}>
                  <TextField
                    fullWidth
                    size="small"
                    value={pile.drilled}
                    onChange={(e) => updatePile(index, "drilled", e.target.value)}
                    onKeyPress={(e) => handleKeyPress(e, index)}
                    placeholder="28.00"
                    variant="standard"
                    InputProps={{
                      disableUnderline: true,
                      inputProps: { "data-pile-index": index },
                    }}
                    sx={{ "& input": { textAlign: "center", fontWeight: "bold" } }}
                  />
                </TableCell>
                <TableCell sx={{ border: "1px solid #000", p: 0.5 }}>
                  <TextField
                    fullWidth
                    size="small"
                    value={pile.notes}
                    onChange={(e) => updatePile(index, "notes", e.target.value)}
                    onKeyPress={(e) => handleKeyPress(e, index)}
                    placeholder="28. BOŞ FORAJ"
                    variant="standard"
                    InputProps={{
                      disableUnderline: true,
                      inputProps: { "data-pile-index": `${index}-notes` },
                    }}
                    sx={{ "& input": { fontSize: "0.9rem" } }}
                  />
                </TableCell>
                <TableCell sx={{ border: "1px solid #000", textAlign: "center", p: 0.5 }}>
                  <IconButton
                    size="small"
                    color="error"
                    onClick={() => removePile(index)}
                    disabled={data.length <= 1}
                    sx={{ minWidth: "auto", p: 0.5 }}
                  >
                    <Delete fontSize="small" />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>

        <Box sx={{ display: "flex", justifyContent: "center" }}>
          <Button
            variant="contained"
            startIcon={<Add />}
            onClick={addPile}
            sx={{
              backgroundColor: "#795548",
              color: "white",
              "&:hover": { backgroundColor: "#5d4037" },
            }}
          >
            {t("add")} {t("pile")}
          </Button>
        </Box>

        <Box sx={{ mt: 2, p: 2, backgroundColor: "rgba(121, 85, 72, 0.1)", borderRadius: 1 }}>
          <Typography variant="body2" color="text.secondary">
            💡 <strong>İpucu:</strong> Yeni satır eklemek için Enter tuşuna basın veya "Kazık Ekle" butonunu kullanın.
          </Typography>
        </Box>
      </Paper>
    </Box>
  )
}
